# CareFlow — Member 2: Process Mining Engineer

## Your responsibilities
1. Generate synthetic EHR-style patient event logs.
2. Export a sample CSV early so Member 1 can start the BigQuery/dbt work.
3. Use PM4Py to discover a process model and save a patient-flow diagram.
4. Share the CSV schema and explain how to run the scripts.

## Files
- `data/sample_patient_events.csv` — ready-to-share sample event log (synthetic).
- `src/generate_events.py` — generates a larger synthetic dataset.
- `src/process_mining.py` — discovers a process model using PM4Py.
- `requirements.txt` — Python dependencies.
- `outputs/` — generated process model images are saved here.

## CSV schema
- `Case_ID`: unique process instance / visit ID (e.g. `ER0001`)
- `Activity_Name`: activity recorded by the hospital system
- `Timestamp`: event timestamp in `YYYY-MM-DD HH:MM:SS` format

Optional extra field:
- `Department`: department that recorded the activity. Member 1 may retain it in BigQuery,
  but PM4Py only needs the three columns above.

## Setup
Use Python 3.10+ if possible. From this folder:

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install dependencies:
```bash
python -m pip install -r requirements.txt
```

Generate a larger dataset:
```bash
python src/generate_events.py --cases 500 --output data/patient_events.csv
```

Discover a process model:
```bash
python src/process_mining.py --input data/patient_events.csv
```

The model image is written to `outputs/patient_process_model.png`.

## Important notes
- All included records are synthetic and must not be presented as real hospital data.
- The generated timestamps represent event times, not necessarily queue-entry and service-start times.
  Therefore, elapsed time between events is not automatically the same as true waiting time.
- The sample deliberately includes some X-Ray -> Triage returns for testing. Their rate is controlled
  by the generator and is not evidence of a real hospital bottleneck.
