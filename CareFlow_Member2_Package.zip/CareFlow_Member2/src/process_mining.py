"""Discover a process model from CareFlow event logs using PM4Py."""
import argparse
from pathlib import Path
import pandas as pd
import pm4py

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/sample_patient_events.csv")
    parser.add_argument("--output", default="outputs/patient_process_model.png")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(input_path)
    required = {"Case_ID", "Activity_Name", "Timestamp"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {sorted(missing)}")

    df["Case_ID"] = df["Case_ID"].astype(str).str.strip()
    df["Activity_Name"] = df["Activity_Name"].astype(str).str.strip()
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    df = df.dropna(subset=["Case_ID", "Activity_Name", "Timestamp"])
    df = df.sort_values(["Case_ID", "Timestamp"])

    if df.empty:
        raise ValueError("No valid events remain after timestamp validation.")

    # PM4Py expects the case, activity and timestamp columns to be mapped explicitly.
    event_log = pm4py.format_dataframe(
        df,
        case_id="Case_ID",
        activity_key="Activity_Name",
        timestamp_key="Timestamp"
    )

    net, initial_marking, final_marking = pm4py.discover_petri_net_inductive(event_log)
    pm4py.save_vis_petri_net(
        net, initial_marking, final_marking, str(output_path)
    )

    print(f"Process discovery complete for {df['Case_ID'].nunique()} cases.")
    print(f"Events analyzed: {len(df)}")
    print(f"Saved Petri-net process model: {output_path}")
    print("Note: this is a discovered process model, not a spaghetti diagram.")

if __name__ == "__main__":
    main()
