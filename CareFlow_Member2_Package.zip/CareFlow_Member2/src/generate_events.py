"""Generate synthetic CareFlow patient event logs. No real patient data is used."""
import argparse
import random
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd

ACTIVITIES = [
    ("Registration", "Admissions"),
    ("Triage", "Emergency"),
    ("Doctor Consultation", "Emergency"),
    ("X-Ray", "Radiology"),
    ("Lab Test", "Laboratory"),
    ("Treatment", "Emergency"),
    ("Discharge", "Admissions"),
]

def add_event(rows, case_id, activity, when, department):
    rows.append({
        "Case_ID": case_id,
        "Activity_Name": activity,
        "Timestamp": when.strftime("%Y-%m-%d %H:%M:%S"),
        "Department": department,
    })

def generate(cases=500, seed=42):
    random.seed(seed)
    rows = []
    start = datetime(2026, 10, 1, 7, 0, 0)

    for i in range(1, cases + 1):
        case_id = f"ER{i:05d}"
        current = start + timedelta(
            days=random.randint(0, 13),
            minutes=random.randint(0, 12 * 60)
        )

        # A synthetic patient visit follows a typical ER route.
        add_event(rows, case_id, "Registration", current, "Admissions")
        current += timedelta(minutes=random.randint(2, 8))
        add_event(rows, case_id, "Triage", current, "Emergency")
        current += timedelta(minutes=random.randint(5, 25))
        add_event(rows, case_id, "Doctor Consultation", current, "Emergency")

        current += timedelta(minutes=random.randint(5, 20))
        if random.random() < 0.72:
            current += timedelta(minutes=random.randint(5, 20))
            add_event(rows, case_id, "X-Ray", current, "Radiology")
            current += timedelta(minutes=random.randint(5, 35))

            # Deliberately simulated loop for testing process mining.
            # This is synthetic and does not imply a real paperwork problem.
            if random.random() < 0.20:
                add_event(rows, case_id, "Triage", current, "Emergency")
                current += timedelta(minutes=random.randint(3, 15))
                add_event(rows, case_id, "Doctor Consultation", current, "Emergency")
                current += timedelta(minutes=random.randint(5, 20))

        if random.random() < 0.35:
            current += timedelta(minutes=random.randint(5, 20))
            add_event(rows, case_id, "Lab Test", current, "Laboratory")
            current += timedelta(minutes=random.randint(5, 30))

        current += timedelta(minutes=random.randint(3, 18))
        add_event(rows, case_id, "Treatment", current, "Emergency")
        current += timedelta(minutes=random.randint(2, 15))
        add_event(rows, case_id, "Discharge", current, "Admissions")

    df = pd.DataFrame(rows)
    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df = df.sort_values(["Case_ID", "Timestamp"]).reset_index(drop=True)
    return df

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", type=int, default=500)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="data/patient_events.csv")
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    df = generate(args.cases, args.seed)
    df["Timestamp"] = df["Timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
    df.to_csv(output, index=False)
    print(f"Saved {len(df)} events for {df['Case_ID'].nunique()} cases to {output}")
    print("Synthetic data only. Share this CSV with Member 1 early.")

if __name__ == "__main__":
    main()
